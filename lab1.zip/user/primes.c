#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void pipeline(int pi[2], char* buf)
{
  int pid = fork();
  if(pid == 0)
  {
    close(pi[1]);
    if(read(pi[0], buf, 1) != 0)
    {
      printf("prime %d\n", *buf);
      int p = *buf;
      int flag;
      flag = 0;
      int pp[2];
      while(read(pi[0], buf, 1) != 0)
      {
        int n = *buf;
        if(n % p != 0)
        {
          if(flag == 0)
          {
            flag = 1;
            if(pipe(pp) < 0)
            {
              exit(1);
            }
            pipeline(pp, buf);
            close(pp[0]);
          }
          write(pp[1], buf, 1);
        }
      }
      close(pp[1]);
      wait(0);
      close(pi[0]);
      exit(0);
    }
  }
  else if(pid < 0)
  {
    printf("fork() with wrong");
    exit(1);
  }
}

int
main(int argc, char *argv[])
{
  int pi[2], i;
  char buf[40];
  for(i=0; i<40; i++)
  {
      buf[i] = 1;
  }
  if(pipe(pi) < 0)
  {
    exit(1);
  }
  pipeline(pi, buf);
  close(pi[0]);
  for(i=2; i<36; i++)
  {
    //num = i;
    //write(pi[1], (char *)(&num), 4);
    buf[i-2] = i;
    write(pi[1], &buf[i-2], 1);
  }
  close(pi[1]);
  wait(0);
  exit(0);
}
