#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"



int
main(int argc, char *argv[])
{
  /*
  char *command[2];
  command[0] = "ls";
  command[1] = 0;
  exec(argv[1], command);
  */
  
  char buf[2];
  int pid;
  char *command[32];
  char *temp;
  char *pos;
  if(argc < 2)
  {
    printf("xargs() with error\n");
    exit(1);
  }
  //command[0] = argv[1];
  //printf("command is %s and argv is %s\n", command[0], argv[1]);
  int i;
  for(i=1; i<argc; i++)
  {
    command[i-1] = argv[i];
  }
  i = argc-1;
  temp = (char*)malloc(50);
  pos = temp;
  while(read(0, buf, 1))
  {
    if(*buf == '\n')
    {
      //printf("pos is %s\n", pos);
      command[i++] = pos;
      temp = (char*)malloc(50);
      pos = temp;
    }
    else
    {
      memcpy(temp, buf, 1);
      //printf("temp is %s\n", pos);
      temp++;
    }
  }
  //command[i] = malloc(10);
  // *command[i] = 0;
  //for(i=0; *command[i]!=0; i++)
  //{
  // printf("command is %s\n", command[i]);
  //}
  pid = fork();
  if(pid == 0)
  {
    exec(argv[1], command);
    exit(0);
  }
  else if(pid < 0)
  {
    exit(1);
  }
  wait(0);
  
  exit(0);
}

